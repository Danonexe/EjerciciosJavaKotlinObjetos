package Escuela

class Curso(val nombre: String, val calificacion: Int)