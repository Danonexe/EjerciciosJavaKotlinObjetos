package Escuela

class Profesor(private val nombre: String) {
    fun asignarCurso(estudiante: Estudiante, curso: Curso) {
        println(nombre + " asigna el curso " + curso.nombre + " a " + estudiante.nombre)
        estudiante.agregarCurso(curso)
    }
}
