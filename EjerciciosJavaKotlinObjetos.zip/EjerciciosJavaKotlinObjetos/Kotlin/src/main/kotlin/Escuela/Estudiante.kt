package Escuela

class Estudiante(var nombre: String) {
    private val cursos: ArrayList<Curso>

    init {
        this.cursos = ArrayList<Curso>()
    }

    fun agregarCurso(curso: Curso) {
        cursos.add(curso)
        println(nombre + " ha sido inscrito en el curso de " + curso.nombre)
    }

    fun mostrarPromedio() {
        if (cursos.isEmpty()) {
            println("$nombre no tiene cursos asignados.")
            return
        }

        var sumaCalificaciones = 0
        for (curso in cursos) {
            sumaCalificaciones += curso.calificacion
        }
        val promedio = sumaCalificaciones / cursos.size.toDouble()
        println("El promedio de $nombre es: $promedio")
    }
}
