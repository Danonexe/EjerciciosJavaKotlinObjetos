package GestorDeTareas

class Tarea(val titulo: String, private val descripcion: String, responsable: UsuarioTareas) {
    private var completada = false
    private val responsable: UsuarioTareas = responsable

    fun marcarComoCompletada() {
        this.completada = true
    }

    fun estaCompletada(): Boolean {
        return completada
    }
}
