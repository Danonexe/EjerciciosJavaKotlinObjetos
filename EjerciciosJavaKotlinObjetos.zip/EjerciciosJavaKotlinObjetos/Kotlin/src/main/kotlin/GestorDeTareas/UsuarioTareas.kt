package GestorDeTareas

class UsuarioTareas(val nombre: String, private val email: String)