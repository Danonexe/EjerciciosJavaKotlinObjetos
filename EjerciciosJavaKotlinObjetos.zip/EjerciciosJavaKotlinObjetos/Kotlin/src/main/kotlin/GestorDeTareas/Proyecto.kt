package GestorDeTareas

class Proyecto(private val nombre: String, propietario: UsuarioTareas) {
    private val tareas: ArrayList<Tarea>
    private val propietario: UsuarioTareas = propietario

    init {
        this.tareas = ArrayList<Tarea>()
    }

    fun agregarTarea(tarea: Tarea) {
        tareas.add(tarea)
    }

    fun listarTareas() {
        println("Tareas del proyecto $nombre:")
        for (tarea in tareas) {
            println(
                "- " + tarea.titulo +
                        (if (tarea.estaCompletada()) " (Completada)" else " (Pendiente)")
            )
        }
    }
}
