package Hotel

class Cliente(private val nombre: String) {
    override fun toString(): String {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                '}'
    }
}
