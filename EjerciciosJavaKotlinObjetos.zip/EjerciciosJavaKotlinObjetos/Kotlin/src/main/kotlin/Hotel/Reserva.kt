package Hotel

class Reserva(private val usuario: Cliente, habitacion: Habitacion) {
    private val habitacion: Habitacion


    init {
        habitacion.setReservada(true)
        this.habitacion = habitacion
    }

    override fun toString(): String {
        return "$usuario - $habitacion"
    }
}
