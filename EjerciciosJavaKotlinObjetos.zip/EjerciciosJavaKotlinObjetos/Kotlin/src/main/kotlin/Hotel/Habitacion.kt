package Hotel

class Habitacion(private val id: Int, private var reservada: Boolean) {
    override fun toString(): String {
        return "Habitacion{" +
                "id=" + id +
                ", reservada=" + reservada +
                '}'
    }

    fun setReservada(reservada: Boolean) {
        this.reservada = reservada
    }
}
