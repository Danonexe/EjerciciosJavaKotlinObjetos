import Biblioteca.Biblioteca
import Biblioteca.Libro
import Biblioteca.Usuario
import Escuela.Curso
import Escuela.Estudiante
import Escuela.Profesor
import GestorDeTareas.Proyecto
import GestorDeTareas.Tarea
import GestorDeTareas.UsuarioTareas
import Hotel.Cliente
import Hotel.Habitacion
import Hotel.Reserva
import JuegoRol.Guerrero
import JuegoRol.Hechizo
import JuegoRol.Mago

fun main() {
    var menu: Int

    do {
        println("Escribe que ejercicio quieres ver, 0 para salir")
        menu = readLine()?.toIntOrNull() ?: 0

        when (menu) {
            1 -> {
                // Biblioteca
                val libro = Libro("El Señor de los Anillos", false)
                val usuario = Usuario("Daniel", "Hernández", "1234")
                val biblioteca = Biblioteca()

                println("Inicio de Sesión = ${biblioteca.IniciarSesion(usuario, "1234")}")
                biblioteca.prestarLibro(libro, usuario)
                biblioteca.devolverLibro(libro, usuario)
            }
            2 -> {
                // Hotel
                val cliente = Cliente("Dani")
                val habitacion = Habitacion(1, false)

                val reserva = Reserva(cliente, habitacion)
                val reservas = arrayListOf(reserva)

                for (reservaActual in reservas) {
                    println(reservaActual.toString())
                }
            }
            3 -> {
                // Juego Rol
                val guerrero = Guerrero("Dani", 100)
                val mago = Mago("Gandalf", 80)

                guerrero.atacar(mago)
                mago.lanzarHechizo(guerrero, Hechizo("Bola de Fuego", 20))
                guerrero.mostrarVida()
                mago.mostrarVida()
            }
            4 -> {
                // Escuela
                val profesor = Profesor("Juan Pérez")
                val estudiante = Estudiante("Dani Gómez")
                val cursoMatematicas = Curso("Matemáticas", 85)
                val cursoHistoria = Curso("Historia", 90)

                profesor.asignarCurso(estudiante, cursoMatematicas)
                profesor.asignarCurso(estudiante, cursoHistoria)
                estudiante.mostrarPromedio()
            }
            5 -> {
                // Gestor de Tareas
                val usuario1 = UsuarioTareas("Daniel", "Daniel@email.com")
                val proyecto = Proyecto("HLC", usuario1)

                val tarea1 = Tarea("Hacer Ejercicios JavaKotlin", "Ejercicios", usuario1)
                proyecto.agregarTarea(tarea1)
                proyecto.listarTareas()
                tarea1.marcarComoCompletada()
                println("Después de completar una tarea:")
                proyecto.listarTareas()
            }
        }
    } while (menu != 0)
}

