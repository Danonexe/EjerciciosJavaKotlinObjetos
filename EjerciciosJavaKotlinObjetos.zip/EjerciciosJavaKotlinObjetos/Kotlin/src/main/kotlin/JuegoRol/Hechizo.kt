package JuegoRol

class Hechizo(val nombre: String, val danio: Int)