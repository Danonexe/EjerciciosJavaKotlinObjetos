package JuegoRol

open class Personaje(
    var nombre: String,
    protected var puntosVida: Int
) {

    fun recibirDanio(cantidad: Int) {
        puntosVida -= cantidad
        if (puntosVida < 0) puntosVida = 0
    }

    fun mostrarVida() {
        println("$nombre tiene $puntosVida puntos de vida.")
    }
}