package JuegoRol

class Guerrero(nombre: String?, puntosVida: Int) : Personaje(nombre!!, puntosVida) {
    fun atacar(enemigo: Personaje) {
        println(nombre + " ataca a " + enemigo.nombre + " causando 15 de daño.")
        enemigo.recibirDanio(15)
    }
}