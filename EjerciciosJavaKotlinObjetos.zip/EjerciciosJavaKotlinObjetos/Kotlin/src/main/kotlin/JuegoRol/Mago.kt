package JuegoRol

class Mago(nombre: String?, puntosVida: Int) : Personaje(nombre!!, puntosVida) {
    fun lanzarHechizo(enemigo: Personaje, hechizo: Hechizo) {
        println(nombre + " lanza " + hechizo.nombre + " a " + enemigo.nombre + " causando " + hechizo.danio + " de daño.")
        enemigo.recibirDanio(hechizo.danio)
    }
}
