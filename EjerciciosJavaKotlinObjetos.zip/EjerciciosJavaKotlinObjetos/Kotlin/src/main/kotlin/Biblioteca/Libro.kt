package Biblioteca

class Libro(var titulo: String, var prestado: Boolean)