package Biblioteca

class Usuario(var nombre: String, var apellido: String, var contrasenia: String) {
    private val libros: ArrayList<Libro> = ArrayList<Libro>()

    fun getLibros(): ArrayList<Libro> {
        return libros
    }

    fun addLibro(libro: Libro) {
        libros.add(libro)
    }

    fun removeLibro(libro: Libro) {
        libros.remove(libro)
    }
}
