package Biblioteca

class Biblioteca {
    fun prestarLibro(libro: Libro, usuario: Usuario) {
        if (libro.prestado == false) {
            usuario.addLibro(libro)
            libro.prestado=(true)
            println("Se ha prestado el libro")
        } else {
            println("El libro ya está prestado")
        }
    }

    fun devolverLibro(libro: Libro, usuario: Usuario) {
        if (libro.prestado == true && usuario.getLibros().contains(libro)) {
            usuario.removeLibro(libro)
            println("Se ha devuelto el libro")
        } else {
            println("Este usuario no tiene ese libro")
        }
    }

    fun IniciarSesion(usuario: Usuario, contrasena: String): Boolean {
        return if (usuario.contrasenia == contrasena) {
            true
        } else {
            false
        }
    }
}