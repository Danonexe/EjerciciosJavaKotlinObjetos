import Biblioteca.Biblioteca;
import Biblioteca.Libro;
import Biblioteca.Usuario;
import Escuela.Curso;
import Escuela.Estudiante;
import Escuela.Profesor;
import GestorDeTareas.Proyecto;
import GestorDeTareas.Tarea;
import GestorDeTareas.UsuarioTareas;
import Hotel.Cliente;
import Hotel.Habitacion;
import Hotel.Reserva;
import JuegoRol.Guerrero;
import JuegoRol.Hechizo;
import JuegoRol.Mago;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    int menu=0;
        Scanner sc = new Scanner(System.in);
    do{
        System.out.println("Escribe que ejercicio quieres ver, 0 para salir");
        menu=sc.nextInt();
        if (menu==1){
            //biblioteca
            Libro ESA = new Libro("El Señor de los Anillos", false);
            Usuario usuario = new Usuario("Daniel","Hernández","1234");
            Biblioteca biblioteca = new Biblioteca();

            System.out.println("Inicio de Sesión = "+biblioteca.IniciarSesion(usuario,"1234"));
            biblioteca.prestarLibro(ESA,usuario);
            biblioteca.devolverLibro(ESA,usuario);
        }
        if (menu==2){
            //Hotel
            Cliente cliente = new Cliente("Dani");
            Habitacion habitacion = new Habitacion(1, false);

            Reserva reserva = new Reserva(cliente, habitacion);
            ArrayList<Reserva> reservas = new ArrayList<Reserva>();
            reservas.add(reserva);

            for (Reserva reservaActual : reservas) {
                System.out.println(reservaActual.toString());
            }

        }
        if (menu==3){
            //juego Rol
            Guerrero guerrero = new Guerrero("Dani", 100);
            Mago mago = new Mago("Gandalf", 80);

            guerrero.atacar(mago);
            mago.lanzarHechizo(guerrero, new Hechizo("Bola de Fuego", 20));
            guerrero.mostrarVida();
            mago.mostrarVida();
        }
        if(menu==4){
            //Escuela
            Profesor profesor = new Profesor("Juan Pérez");
            Estudiante estudiante = new Estudiante("Dani Gómez");
            Curso cursoMatematicas = new Curso("Matemáticas", 85);
            Curso cursoHistoria = new Curso("Historia", 90);

            profesor.asignarCurso(estudiante, cursoMatematicas);
            profesor.asignarCurso(estudiante, cursoHistoria);
            estudiante.mostrarPromedio();
        }
        if(menu==5){
            //Gestor de tareas
            UsuarioTareas usuario1 = new UsuarioTareas("Daniel", "Daniel@email.com");            // Crear un proyecto
            Proyecto proyecto = new Proyecto("HLC", usuario1);

            // Crear y agregar tareas
            Tarea tarea1 = new Tarea("Hacer Ejercicios JavaKotlin", "Ejercicios", usuario1);

            proyecto.agregarTarea(tarea1);
            proyecto.listarTareas();
            tarea1.marcarComoCompletada();
            System.out.println("Después de completar una tarea:");
            proyecto.listarTareas();
        }

    }while(menu!=0);
    }
}
