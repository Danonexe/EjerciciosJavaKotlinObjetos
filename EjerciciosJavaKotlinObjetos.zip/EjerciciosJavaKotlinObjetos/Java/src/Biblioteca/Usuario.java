package Biblioteca;

import java.util.ArrayList;

public class Usuario {
    private String nombre;
    private String apellido;
    private String contrasenia;
    private ArrayList<Libro> libros = new ArrayList<Libro>();

    public Usuario(String nombre, String apellido, String contrasenia) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.contrasenia = contrasenia;

    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public ArrayList<Libro> getLibros() {
        return libros;
    }
    public void addLibro(Libro libro) {
        libros.add(libro);
    }
    public void removeLibro(Libro libro) {
        libros.remove(libro);
    }

}
