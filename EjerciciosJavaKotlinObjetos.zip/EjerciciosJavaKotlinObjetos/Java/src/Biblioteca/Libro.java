package Biblioteca;

public class Libro {
    private String titulo;
    private boolean prestado;

    public Libro(String titulo, boolean prestado) {
        this.titulo = titulo;
        this.prestado = prestado;
    }

    public String getTitulo() {
        return titulo;
    }

    public boolean getPrestado() {
        return prestado;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setPrestado(boolean prestado) {
        this.prestado = prestado;
    }

}
