package Biblioteca;

public class Biblioteca {
    public void prestarLibro(Libro libro,Usuario usuario) {
        if(libro.getPrestado()==false) {
            usuario.addLibro(libro);
            libro.setPrestado(true);
            System.out.println("Se ha prestado el libro");
        }else{
            System.out.println("El libro ya está prestado");
        }
    }

    public void devolverLibro(Libro libro,Usuario usuario) {
        if(libro.getPrestado()==true && usuario.getLibros().contains(libro)) {
            usuario.removeLibro(libro);
            System.out.println("Se ha devuelto el libro");
        }else{
            System.out.println("Este usuario no tiene ese libro");
        }
    }
    public boolean IniciarSesion(Usuario usuario,String contrasena) {
        if(usuario.getContrasenia().equals(contrasena)) {
            return true;
        }else{
            return false;
        }
    }

    public Biblioteca() {
    }

}
