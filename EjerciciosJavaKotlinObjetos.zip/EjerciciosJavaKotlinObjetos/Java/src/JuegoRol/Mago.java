package JuegoRol;

public class Mago extends Personaje {

    public Mago(String nombre, int puntosVida) {
        super(nombre, puntosVida);
    }

    public void lanzarHechizo(Personaje enemigo, Hechizo hechizo) {
        System.out.println(nombre + " lanza " + hechizo.getNombre() + " a " + enemigo.nombre + " causando " + hechizo.getDanio() + " de daño.");
        enemigo.recibirDanio(hechizo.getDanio());
    }
}
