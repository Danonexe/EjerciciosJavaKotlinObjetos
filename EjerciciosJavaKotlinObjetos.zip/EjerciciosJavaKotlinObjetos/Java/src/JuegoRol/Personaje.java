package JuegoRol;

class Personaje {
    protected String nombre;
    protected int puntosVida;

    public Personaje(String nombre, int puntosVida) {
        this.nombre = nombre;
        this.puntosVida = puntosVida;
    }

    public void recibirDanio(int cantidad) {
        puntosVida -= cantidad;
        if (puntosVida < 0) puntosVida = 0;
    }

    public void mostrarVida() {
        System.out.println(nombre + " tiene " + puntosVida + " puntos de vida.");
    }
}
