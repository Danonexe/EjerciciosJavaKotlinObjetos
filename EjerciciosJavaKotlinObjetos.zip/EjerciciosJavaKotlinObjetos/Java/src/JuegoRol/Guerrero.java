package JuegoRol;

public class Guerrero extends Personaje {

    public Guerrero(String nombre, int puntosVida) {
        super(nombre, puntosVida);
    }

    public void atacar(Personaje enemigo) {
        System.out.println(nombre + " ataca a " + enemigo.nombre + " causando 15 de daño.");
        enemigo.recibirDanio(15);
    }
}

