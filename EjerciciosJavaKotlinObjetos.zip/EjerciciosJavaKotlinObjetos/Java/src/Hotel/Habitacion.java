package Hotel;

public class Habitacion {
    private int id;
    private boolean reservada;

    public Habitacion(int id, boolean reservada) {
        this.id = id;
        this.reservada = reservada;
    }

    @Override
    public String toString() {
        return "Habitacion{" +
                "id=" + id +
                ", reservada=" + reservada +
                '}';
    }

    public void setReservada(boolean reservada) {
        this.reservada = reservada;
    }
}
