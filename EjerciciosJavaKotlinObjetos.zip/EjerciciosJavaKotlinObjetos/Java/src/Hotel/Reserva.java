package Hotel;

import java.util.ArrayList;

public class Reserva {
    private Cliente usuario;
    private Habitacion habitacion;


    public Reserva(Cliente usuario, Habitacion habitacion) {
        this.usuario = usuario;
        habitacion.setReservada(true);
        this.habitacion = habitacion;
    }
    public String toString(){
        return usuario.toString() + " - " + habitacion.toString();
    }
}
