package GestorDeTareas;

public class UsuarioTareas {
    private String nombre;
    private String email;

    public UsuarioTareas(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }
}
