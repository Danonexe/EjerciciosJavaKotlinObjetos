package GestorDeTareas;

public class Tarea {
    private String titulo;
    private String descripcion;
    private boolean completada;
    private UsuarioTareas responsable;

    public Tarea(String titulo, String descripcion, UsuarioTareas responsable) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.completada = false;
        this.responsable = responsable;
    }

    public void marcarComoCompletada() {
        this.completada = true;
    }

    public boolean estaCompletada() {
        return completada;
    }

    public String getTitulo() {
        return titulo;
    }
}
