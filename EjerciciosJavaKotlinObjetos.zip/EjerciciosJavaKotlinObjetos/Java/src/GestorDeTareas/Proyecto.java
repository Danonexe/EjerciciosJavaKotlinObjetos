package GestorDeTareas;

import java.util.ArrayList;

public class Proyecto {
    private String nombre;
    private ArrayList<Tarea> tareas;
    private UsuarioTareas propietario;

    public Proyecto(String nombre, UsuarioTareas propietario) {
        this.nombre = nombre;
        this.propietario = propietario;
        this.tareas = new ArrayList<>();
    }

    public void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }

    public void listarTareas() {
        System.out.println("Tareas del proyecto " + nombre + ":");
        for (Tarea tarea : tareas) {
            System.out.println("- " + tarea.getTitulo() +
                    (tarea.estaCompletada() ? " (Completada)" : " (Pendiente)"));
        }
    }

}
