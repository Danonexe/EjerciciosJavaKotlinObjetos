package Escuela;

public class Profesor {
    private String nombre;

    public Profesor(String nombre) {
        this.nombre = nombre;
    }

    public void asignarCurso(Estudiante estudiante, Curso curso) {
        System.out.println(nombre + " asigna el curso " + curso.getNombre() + " a " + estudiante.nombre);
        estudiante.agregarCurso(curso);
    }
}
