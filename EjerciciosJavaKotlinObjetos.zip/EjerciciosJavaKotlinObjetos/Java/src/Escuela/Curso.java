package Escuela;

public class Curso {
    private String nombre;
    private int calificacion;

    public Curso(String nombre, int calificacion) {
        this.nombre = nombre;
        this.calificacion = calificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCalificacion() {
        return calificacion;
    }
}
