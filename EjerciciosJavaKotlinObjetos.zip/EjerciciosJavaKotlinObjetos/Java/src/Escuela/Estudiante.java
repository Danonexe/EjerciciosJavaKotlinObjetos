package Escuela;

import java.util.ArrayList;

public class Estudiante {
    public String nombre;
    private ArrayList<Curso> cursos;

    public Estudiante(String nombre) {
        this.nombre = nombre;
        this.cursos = new ArrayList<>();
    }

    public void agregarCurso(Curso curso) {
        cursos.add(curso);
        System.out.println(nombre + " ha sido inscrito en el curso de " + curso.getNombre());
    }

    public void mostrarPromedio() {
        if (cursos.isEmpty()) {
            System.out.println(nombre + " no tiene cursos asignados.");
            return;
        }

        int sumaCalificaciones = 0;
        for (Curso curso : cursos) {
            sumaCalificaciones += curso.getCalificacion();
        }
        double promedio = sumaCalificaciones / (double) cursos.size();
        System.out.println("El promedio de " + nombre + " es: " + promedio);
    }
}
